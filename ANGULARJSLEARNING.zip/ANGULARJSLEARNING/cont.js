var app = angular.module('demoApp', []);

app.controller('demoController', function($scope) {
  $scope.formData = {}
  $scope.serialize = function($event){
    console.log($scope.formData)
    alert(JSON.stringify($scope.formData))
    $event.preventDefault()
  }
});