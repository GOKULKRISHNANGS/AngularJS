package angularform.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import angularform.form.AngularBean;


@RestController
@RequestMapping(value = "/stocks")
public class AngularController {

	@RequestMapping(value = "/all", method = RequestMethod.PUT)
	public String getAllStocks(@RequestBody AngularBean angularbean) {
		System.out.println("Inside Controller");
		AngularDAO angulardao = new AngularDAO();
		int result = angulardao.displayDetails(angularbean);
		System.out.println("Successfull" + result);
		return "Success";
	}

}