package angularform.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import angularform.form.AngularBean;

public class AngularDAO {
	
	ConnectionDB connect = new ConnectionDB();
	Connection con = null;
	
	public int displayDetails(AngularBean angularbean){
		System.out.println(angularbean.getName()+" "+angularbean.getAge()+" "+angularbean.getAddress());
		int result = 0;
		
		try{
			con = connect.getConnection();
			String query = "insert into T_XBBNHGY_ANGULAR values(?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, angularbean.getName());
			stmt.setString(2, angularbean.getAge());
			stmt.setString(3, angularbean.getAddress());
			result = stmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return result;
	}
}
