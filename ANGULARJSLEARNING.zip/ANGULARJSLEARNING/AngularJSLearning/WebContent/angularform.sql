create table T_XBBNHGY_ANGULAR(name varchar(30), age varchar(3),city varchar(30));

select * from T_XBBNHGY_ANGULAR;