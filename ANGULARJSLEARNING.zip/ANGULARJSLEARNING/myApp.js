var myApp = angular.module("myApp",[]);
myApp.controller("MyController",["$scope", "$rootScope", function MyController($scope, $rootScope){
	$rootScope.name = "Hello EveryOne!";
	$scope.details = [{
		name: 'Anu',
		city:'Chennai',
		age: '22'
	},
	{
		name: 'Gayathri',
		city: 'Kumbakonam',
		age: '22'
	}]
	
	}]);